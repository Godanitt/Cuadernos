#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v typst >/dev/null 2>&1; then
  echo "ERROR: typst is not installed or not in PATH." >&2
  echo "Install Typst, then run: typst compile paper.typ paper.pdf" >&2
  exit 127
fi

typst compile paper.typ paper.pdf
