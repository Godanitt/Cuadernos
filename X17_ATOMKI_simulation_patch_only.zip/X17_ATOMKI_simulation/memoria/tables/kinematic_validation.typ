#table(
  columns: (1.65fr, 1.00fr),
  inset: 4.5pt,
  align: (left, right),
  [*Check*], [*Value*],
  [generated signal events], [10000],
  [invalid angular triplets beyond 1e-3 tolerance], [0 (0.000%)],
  [max raw |cos Delta phi|-1 excess], [4.5139e-04],
  [mean thetaEE generated - input], [-2.8386e-05 deg],
  [RMS thetaEE generated - input], [9.6982e-05 deg],
  [max |thetaEE generated - input|], [9.7000e-04 deg],
  [mean inferred Delta phi], [179.932 deg],
  [mean generated mee], [9.118 MeV/c^2],
)
